from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import pygame

from row_taker.engine.game.cards import Card
from row_taker.gui.constants import CARD_ASPECT_RATIO, CARD_SCALE


@dataclass(slots=True)
class CardSprite:
    card: Card
    image_path: Path | None = None
    x: float = 0.0
    y: float = 0.0
    scale_factor: float = 1.0
    is_face_up: bool = True
    image_orig: pygame.Surface | None = None
    image: pygame.Surface | None = None

    def __post_init__(self) -> None:
        self.validate()

        if self.image_path is None:
            project_root = Path(__file__).resolve().parents[3]
            self.image_path = project_root / "images" / f"{self.value:03}.png"

        if self.image_path.exists():
            self.image_orig = pygame.image.load(str(self.image_path)).convert_alpha()

    def validate(self) -> None:
        self.card.validate()

        if self.scale_factor <= 0:
            raise ValueError(f"scale_factor must be > 0, got {self.scale_factor}")

    @property
    def value(self) -> int:
        return self.card.value

    @property
    def bullheads(self) -> int:
        return self.card.bullheads

    def move_to(self, x: float, y: float) -> None:
        self.x = x
        self.y = y

    def set_scale(self, scale_factor: float) -> None:
        if scale_factor <= 0:
            raise ValueError(f"scale_factor must be > 0, got {scale_factor}")
        self.scale_factor = scale_factor

    def scale(self, window_width: int) -> None:
        if self.image_orig is None:
            self.image = None
            return

        width = int(window_width * CARD_SCALE * self.scale_factor)
        height = int(width * CARD_ASPECT_RATIO)
        self.image = pygame.transform.scale(self.image_orig, (width, height))

    def draw(self, surface: pygame.Surface) -> None:
        if self.image is not None:
            surface.blit(self.image, (self.x, self.y))
