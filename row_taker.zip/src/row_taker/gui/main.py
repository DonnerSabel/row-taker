import pygame

from row_taker.engine.game.cards import Card
from row_taker.gui.card import CardSprite
from row_taker.gui.constants import (
    BACKGROUND_COLOR,
    CARD_GAP,
    DEMO_CARD_VALUES,
    FPS,
    WINDOW_HEIGHT,
    WINDOW_TITLE,
    WINDOW_WIDTH,
)
from row_taker.gui.spielfeld import Spielfeld


def create_demo_cards(window_width: int, window_height: int) -> list[CardSprite]:
    deck = [CardSprite(Card(value)) for value in DEMO_CARD_VALUES]

    for card_sprite in deck:
        card_sprite.scale(window_width)

    x_pos = CARD_GAP
    for card_sprite in deck:
        if card_sprite.image is None:
            continue
        card_sprite.x = x_pos
        card_sprite.y = window_height // 2 - card_sprite.image.get_height() // 2
        x_pos += card_sprite.image.get_width() + CARD_GAP

    return deck


def run() -> int:
    pygame.init()
    spielfeld = Spielfeld()
    spielfeld.load_image()
    try:
        screen = pygame.display.set_mode(spielfeld.get_image_size())
        pygame.display.set_caption(WINDOW_TITLE)
        clock = pygame.time.Clock()

        deck = create_demo_cards(WINDOW_WIDTH, WINDOW_HEIGHT)

        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            if spielfeld.image is None:
                screen.fill(BACKGROUND_COLOR)
            else:
                spielfeld.draw(screen)

            for card in deck:
                card.draw(screen)

            pygame.display.flip()
            clock.tick(FPS)

        return 0
    finally:
        pygame.quit()
